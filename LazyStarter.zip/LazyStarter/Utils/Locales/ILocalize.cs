﻿namespace LazyStarter
{
    public interface ILocalize
    {
        void Localize(string locale);
    }
}
